import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import ScoreboardApp from './ScoreboardApp.jsx'

const root = createRoot(document.getElementById('root'))

root.render(
  <StrictMode>
    <ScoreboardApp />
  </StrictMode>,
)

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then(registration => {
        console.log('Service Worker registered:', registration.scope)
      })
      .catch(error => {
        console.warn('Service Worker registration failed:', error)
      })
  })
}